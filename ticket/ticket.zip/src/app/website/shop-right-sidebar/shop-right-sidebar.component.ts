import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-right-sidebar',
  templateUrl: './shop-right-sidebar.component.html',
  styleUrls: ['./shop-right-sidebar.component.css']
})
export class ShopRightSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
