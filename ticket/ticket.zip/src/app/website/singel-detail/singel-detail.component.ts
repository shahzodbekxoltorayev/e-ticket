import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-singel-detail',
  templateUrl: './singel-detail.component.html',
  styleUrls: ['./singel-detail.component.css']
})
export class SingelDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
